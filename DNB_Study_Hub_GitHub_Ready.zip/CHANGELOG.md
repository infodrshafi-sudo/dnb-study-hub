# DNB Study Hub release history

## Version 4.0 — November 2026

### Study library
- Now includes 18 specialties and 690 accessible topics.
- Adds Critical Care/Palliative/Oncology/Geriatrics, Equipment/Physics/Recovery/Miscellaneous, and Respiratory/Airway/Larynx specialties.
- Integrates the seven previously pending specialties: Pharmacology, Renal/Transplant, Neuro, Gastro/Hepatic/Infectious Diseases, Cardiac/CTVS, Regional/Pain/Ultrasound, and Practical/OSCE.
- Consolidates repeated headings where safe and provides related links for cross-specialty overlaps.
- Rebuilds the Endocrine PDF-derived study pages to better reconstruct original bullet hierarchy and wrapped lines.
- Removes identifiable revision-only remarks and sample-case identifiers where recognized.
- Maintains compatibility with already-saved Version 3 topic IDs.

### Reading and revision
- New clean reader, collapsible table of contents, adjustable font, dark mode and reading progress.
- Auto-save last reading position.
- One-click status cycle plus Undo; dated status changes support spaced-review suggestions.
- Five-status summary, overdue review list and specialty progress.
- Improved backup export/restore and existing bookmarks.

### Performance, search and offline
- Topic content is loaded on demand instead of loading every full document at startup.
- Search indexing runs off the main thread, with title/heading ranking, snippets and section links.
- Download specialty-specific content and images offline; app shell cached by a service worker.
- Accessibility improvements: semantic buttons, labelled actions, keyboard-accessible diagrams, focus outlines and reduced motion support.

### QA and known limitations
- Structural integrity tests for references, lists, tables, images and previously saved IDs.
- Not a formal medical-content verification or cross-browser certification. Complex Word layout and some annotations require manual review.
