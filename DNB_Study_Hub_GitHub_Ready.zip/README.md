# DNB Study Hub — Version 4.0

An installable, responsive study-notes application created for **Dr. Shafi**. Ready for your existing GitHub Pages ZIP extraction workflow.

## What is included

**18 specialty collections and 690 topics**, including all previously integrated notes and the recently supplied Pharmacology; Renal; Neuro; Gastro/Hepatic; Cardiac; Regional/Pain; Practical/OSCE; Critical Care; Equipment/Physics; and Respiratory/Airway documents.

The source Word/PDF documents **are not included** in the website. Instead, topics are converted into HTML with headings, properly nested lists, tables, emphasis, figures and optimized illustrations. There is **no in-app document importer or original-file viewer**.

## What's new

- **Focused reading screen** with collapsible contents, a reading progress indicator and automatic restoration of your previous reading position.
- **Revision status:** one compact tap-to-cycle control (`○ Not started → ◉ Studying → ✓ Revised once → ✓✓ Revised twice → ★ Mastered`). An **Undo** button appears after any change.
- **Spaced revision dashboard** with adjustable due intervals (1, 3, 7, 30 days by default), accurate five-stage totals, and specialty summaries. Dates are tracked on future status changes.
- **Improved global search**, activated on demand and running in a Web Worker. Results prioritize titles and headings and include a contextual excerpt; results link into matching sections.
- **Lazy topic loading:** the dashboard only loads specialty/topic metadata; each full topic is fetched on opening. Search text is loaded only when searching.
- **Offline specialty packs:** under Settings, download specific specialties including their notes and images for offline study. Browser storage can still be cleared by the device/browser.
- **Bookmarks, dark mode, adjustable font size, image zoom and export/restore backup.**
- **Content cleanup:** removed identifiable personal revision markers, reformatted multilevel lists, consolidated exact repeated headings within specialties, and linked overlapping topics across specialties without deleting distinct study material.
- **Structural quality checks:** checked topic IDs, references, images, table/list conversion, and archive integrity. See `QUALITY_REPORT.json`.

## Update your existing GitHub repository

Your existing workflow at `.github/workflows/deploy.yml` should be retained unchanged.

1. Download `DNB_Study_Hub_GitHub_Ready.zip` from ChatGPT.
2. Open https://github.com/infodrshafi-sudo/dnb-study-hub.
3. **Replace the old ZIP file in the repository root with the new ZIP**, preserving the exact name `DNB_Study_Hub_GitHub_Ready.zip`.
4. Commit the replacement. If GitHub's web editor does not offer replacement, delete the old ZIP and commit; then upload the new ZIP and commit.
5. The existing GitHub Actions workflow extracts the ZIP and publishes GitHub Pages automatically.
6. After the workflow succeeds, open https://infodrshafi-sudo.github.io/dnb-study-hub/ and refresh. If the old version persists, close the tab/reopen the site or refresh after the updated service worker activates.

**Do not extract the ZIP or upload the website files individually** when using your ZIP extraction workflow.

## Study progress continuity

All **187 identifiers from the last published Version 3 ZIP are retained or migrated**. The original localStorage namespace, `dnb-study-v1-`, is unchanged, so bookmarks and revision statuses should persist at the same GitHub Pages domain/browser. The app also preserves saved topics from the pending development library. Export a backup from Settings before any major browser/site-data changes.

The progress backup is a `.json` file stored on your device; it is not sent to any server.

## Important clinical and privacy limitations

- **Medical content has not been clinically fact-checked or systematically updated against 2026 guidelines.** It is based on your uploaded study documents. Do not use doses or protocols as direct clinical orders without verifying the current authoritative source.
- The included changes are the latest app updates and additions from your supplied files, **not a claim that every medical reference is current**.
- There is no patient database or account. However, **GitHub Pages is public**, and all published study text/images can be accessed by others. Please review any illustrative clinical cases for confidential personal details before publishing.
- Specialty import removes obvious editorial/revision markers conservatively, but unusual embedded annotations may still need manual correction.
- Word's floating shapes and unusually complex tables can require manual checking after HTML conversion.
- Offline packs are per specialty. A browser can reclaim local offline storage. Back up revision progress periodically.

## Technical structure

- `index.html`, `app.js`, `style.css`: responsive static application
- `search-worker.js`: background full-text search
- `sw.js`: service worker for offline access and fallback
- `data/index.json`: light metadata with specialties/topic IDs
- `data/content/*.json`: one full study topic per file
- `data/search/*.json`: per-specialty search data, loaded on demand
- `data/offline/*.json`: per-specialty offline asset manifests
- `data/aliases.json`: stable ID mappings for merged topics
- `data/related.json`: cross-specialty related topic links
- `assets/images/`: optimized embedded diagrams
- `QUALITY_REPORT.json`: automated integrity metrics

## Preview locally

If needed, unzip and open a terminal in the extracted directory:

```sh
python -m http.server 8000
```

Then visit `http://localhost:8000`. Opening `index.html` directly as `file://` may prevent JSON loading in browsers.


**Source update:** Endocrine & Obesity topics now come from `endocrine,obesity(1).docx`, not the previously supplied PDF.
