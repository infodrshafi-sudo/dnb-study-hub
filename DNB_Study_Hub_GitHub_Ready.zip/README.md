# DNB Study Hub — Dr. Shafi

A static, mobile-friendly anesthesia revision application. No account, backend, or document-upload system is required.

## Included study material

- Obstetric Anesthesia — 25 topics (converted from OBG.docx)
- Head, Neck, ENT & Ophthalmic Anesthesia — 18 topics (converted from the supplied DOCX)
- Trauma, Orthopedics & Hematology — 28 topics (converted from the supplied DOCX)
- Endocrine & Obesity Anesthesia — 20 topics (original PDF viewer)

**Total: 91 study topics.** The converted DOCX content includes rich text, tables, highlighted text, and embedded images. The original Endocrine PDF is included for full fidelity.

## Features

- Specialty dashboard, individual topic reader, automatic section index
- Search across converted DOCX text (PDF topics searchable by title only; PDF retains its own in-viewer text search)
- Bookmarks, revision states, recent topics, and revision overview
- Light and dark modes, adjustable reading font
- Image zoom, mobile layout
- Export and restore revision-progress backup
- No in-app document uploads. To expand the library, send new DOCX/PDF documents to ChatGPT and request an updated ZIP.

## Publish to GitHub Pages (no coding required)

1. Create a **public** repository at https://github.com/new named `dnb-study-hub`.
2. Download this ZIP and **extract** it on your computer.
3. In the repository, use **Add file → Upload files**.
4. Upload **all contents from the extracted folder**, keeping `index.html`, `app.js`, `style.css`, `data/`, `assets/`, and `source/` in their original folders. Do not upload just the ZIP.
5. Commit the changes.
6. Go to **Settings → Pages**. Under **Build and deployment**, select **Deploy from a branch**, `main`, `/ (root)`, and Save.
7. Your app will appear at `https://YOUR-USERNAME.github.io/dnb-study-hub/` after GitHub finishes publishing.

For updates, replace the repository's existing app files with the contents of the new ZIP, keeping the same repository URL.

## Local preview

Directly opening `index.html` as a `file://` URL may block JSON fetches in browsers. Instead, in the extracted folder run:

```sh
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Where content lives

`data/index.json` lists specialties. Each `data/<specialty>.json` contains topic HTML and metadata. Images are inside `assets/images/`. The Endocrine PDF is `source/endocrine-obesity.pdf`.

## Study progress and privacy

Progress and bookmarks are saved in browser localStorage, not in GitHub. Normally, updates at the **same site URL** keep existing browser progress. Browser data may be lost by clearing browsing/site data, switching devices or private mode. Use **Settings → Export progress backup** if needed, and restore it in a new browser.

Your notes are imported **as supplied**, not independently fact-checked. Drug doses and clinical guidance should be independently verified before clinical use.

## Notes on formatting

Word heading styles are used as topic and section boundaries. Most text formatting, embedded pictures, emphasis, and tables are preserved. Some specialized Word layout (floating text boxes, custom shapes, page geometry, numbering styles, and fields) may not reproduce exactly in HTML; check the source material for such cases. Embedded images are preserved as images.

The PDF source is displayed intact in the viewer. Browser PDF support varies by device.
