# DNB Study Hub — Dr. Shafi (Version 2)

Static, mobile-friendly DNB Anesthesia study application built from user-provided study notes.

## Included notes

| Specialty | Topics |
| --- | ---: |
| Obstetric Anesthesia | 25 |
| Head, Neck, ENT & Ophthalmic Anesthesia | 18 |
| Trauma, Orthopedics & Hematology | 28 |
| Endocrine & Obesity Anesthesia | 20 |
| **Total** | **91** |

## New in Version 2

- All four specialties converted to readable web HTML. No source PDF/DOCX files are packaged.
- Removed the original-file PDF viewer, original-file links, and source directory.
- Kept headings, source text, tables, embedded figures, and emphasis where extractable.
- Removed identifiable study-time and revision-only annotations (e.g., SR, DRA, only exam, short timed notes).
- Optimized pictures and diagrams to reduce deployment size.
- Replaced the revision-status dropdown with a **single compact click-to-cycle button**:
  Not started → Studying → Revised once → Revised twice → Mastered → Not started.
- Existing stable topic IDs and browser progress keys remain compatible with Version 1.

## Hosting — your existing ZIP extraction workflow

1. Extracting manually is **not necessary** when using the existing GitHub Actions ZIP workflow.
2. Upload the new `DNB_Study_Hub_GitHub_Ready.zip` to the **root** of your `dnb-study-hub` repository.
3. Replace the old ZIP **using the exact same filename**.
4. Commit the upload; the existing `.github/workflows/deploy.yml` workflow automatically extracts and deploys it.
5. If GitHub does not let you replace the file in the web editor, delete the old ZIP first, commit, then upload the new ZIP and commit.

Do not extract or upload the `data/` and `assets/` folders manually when using your working ZIP workflow.

## Existing functionality

Specialty library, topic navigation, section index, full-text search, bookmarks, revision status, recent topics, reading font size, light/dark mode, clickable image enlargement, export/restore progress.

No document upload, admin panel, server, or sign-in inside the app.

## Expansion workflow

Send future files in ChatGPT and request a refreshed ZIP. Future releases should preserve existing topic IDs so the site's local progress remains compatible.

## Important notes

- Browsers store progress using `localStorage`, not GitHub. Stay on the same domain, and export a backup before any major migration.
- Word floating shapes/custom layout and PDF complex multi-column positioning do not always map perfectly into HTML. Tables and embedded figures are preserved where recognized; the PDF conversion uses extracted text and table/image elements and may not replicate every line break exactly.
- Source content is transcribed, **not medically verified**. Review clinical drugs, dosages, and recommendations independently before clinical use.
