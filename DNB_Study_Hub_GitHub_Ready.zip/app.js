
const $=id=>document.getElementById(id);
const escapeHTML=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ICONS={'obg':'🤰','head-neck':'👁️','trauma':'🚑','endocrine':'🧬'};
const STORE='dnb-study-v1-';
const saved=(k,f)=>{try{return JSON.parse(localStorage.getItem(STORE+k))??f}catch{return f}};
const persist=(k,v)=>localStorage.setItem(STORE+k,JSON.stringify(v));
let library=[], specs=[], currentSpec=null, currentTopic=null;
let progress=saved('progress',{}),bookmarks=saved('bookmarks',{}),settings=saved('settings',{dark:false,font:17}),history=[];
if(settings.dark)document.body.classList.add('dark');
const topicFor=id=>library.flatMap(s=>s.topics.map((t,i)=>({...t,_spec:s,_index:i}))).find(t=>t.id===id);
const allTopics=()=>library.flatMap(s=>s.topics.map((t,i)=>({...t,_spec:s,_index:i})));
const status=t=>progress[t.id]||'Not started';
const getSpec=id=>library.find(s=>s.id===id);
function navigate(path){location.hash=path;render();$('sidebar').classList.remove('show');scrollTo(0,0)}
function fromHash(){return decodeURIComponent(location.hash.slice(1)||'/')}
function button(text,path,more=''){return `<button class="btn ${more}" data-link="${escapeHTML(path)}">${text}</button>`}
const pct=s=>{const n=s.topics.filter(t=>status(t)!=='Not started').length;return Math.round(100*n/Math.max(1,s.topics.length))};
function nav(){
 const loc=fromHash();
 $('sideNav').innerHTML=[
 ['⌂','Dashboard','/'],['⌕','Search','/search'],['☆','Bookmarks','/bookmarks'],['◷','Revision progress','/progress'],['⚙','Settings','/settings']
 ].map(([icon,label,url])=>`<button class="navbtn ${loc===url?'active':''}" data-link="${url}"><span>${icon}</span>${label}</button>`).join('');
 $('sideSpecs').innerHTML=library.map(s=>`<button class="navbtn ${loc.includes(s.id)?'active':''}" data-link="/specialty/${s.id}"><span>${ICONS[s.id]||'📖'}</span><span>${escapeHTML(s.short)}</span><span class="count">${s.topics.length}</span></button>`).join('');
}
function shell(title,desc='',extra=''){return `<div class="header"><div><h1>${escapeHTML(title)}</h1><p class="subtext">${escapeHTML(desc)}</p></div><div class="actions">${extra}</div></div>`}
function dashboard(){
 let done=allTopics().filter(t=>status(t)!=='Not started').length;
 let bookmarked=Object.values(bookmarks).filter(Boolean).length;
 const items=library.map(s=>`<div class="specialty" data-link="/specialty/${s.id}" role="button" tabindex="0"><span class="em">${ICONS[s.id]||'📖'}</span><h3>${escapeHTML(s.name)}</h3><p>${s.topics.length} topics · ${s.type==='pdf'?'Original PDF':'Formatted study notes'}</p><div class="progressbar"><div style="width:${pct(s)}%"></div></div><p style="margin-top:8px">${pct(s)}% started</p></div>`).join('');
 const recent=history.filter(t=>topicFor(t)).slice(0,4).map(id=>topicCard(topicFor(id))).join('');
 $('app').innerHTML=shell('Your study library','Read, revise, and track anesthesia topics at your pace.')+
 `<div class="stats"><div class="stat"><strong>${library.length}</strong><span>Specialties</span></div><div class="stat"><strong>${allTopics().length}</strong><span>Topics</span></div><div class="stat"><strong>${done}</strong><span>Topics started</span></div></div><div class="searchbox"><input class="search" id="homeSearch" placeholder="Search all notes and topics…" aria-label="Search notes"></div><h2 class="section-title" style="margin-top:30px">Specialties</h2><div class="cards">${items}</div><h2 class="section-title">Continue studying</h2>${recent?`<div class="topic-list">${recent}</div>`:'<div class="empty">Open a topic to start your study journey.</div>'}`;
 $('homeSearch').addEventListener('keydown',e=>{if(e.key==='Enter')navigate('/search?q='+encodeURIComponent(e.target.value))});
}
function topicCard(t){
 return `<div class="topic-card" role="button" tabindex="0" data-link="/topic/${encodeURIComponent(t.id)}"><span style="font-size:22px">${ICONS[t._spec.id]||'📖'}</span><div style="flex:1;min-width:0"><div class="topic-name">${escapeHTML(t.title)}</div><div class="topic-meta">${escapeHTML(t._spec.short)}${t.page?' · p. '+t.page:''} · ${status(t)!=='Not started'?escapeHTML(status(t)):'Not started'}</div></div><span class="chip">${bookmarks[t.id]?'★':'›'}</span></div>`;
}
function specialty(id){
 let s=getSpec(id);if(!s)return errorPage();
 $('app').innerHTML=shell(s.name,`${s.topics.length} study topics · ${s.type==='pdf'?'PDF source format':'DOCX source format'}`,button('← Home','/'))+
 `<div class="panel"><div style="display:flex;justify-content:space-between"><strong>Study progress</strong><span>${pct(s)}% started</span></div><div class="progressbar" style="margin-top:11px"><div style="width:${pct(s)}%"></div></div></div><div class="searchbox"><input class="search" id="filterTopic" placeholder="Filter topics in this specialty…"></div><div class="topic-list" id="topicList">${s.topics.map((t,i)=>topicCard({...t,_spec:s,_index:i})).join('')}</div>`;
 $('filterTopic').oninput=e=>{const q=e.target.value.toLocaleLowerCase();$('topicList').innerHTML=s.topics.map((t,i)=>({...t,_spec:s,_index:i})).filter(t=>t.title.toLocaleLowerCase().includes(q)).map(topicCard).join('')||'<div class="empty">No matching topics.</div>'};
}
function reader(id){
 const t=topicFor(id);if(!t)return errorPage();
 if(history[0]!==t.id){history=[t.id,...history.filter(x=>x!==t.id)].slice(0,20);persist('recent',history)}
 let s=t._spec,others=s.topics,previous=others[t._index-1],next=others[t._index+1];
 let selected=status(t),opts=['Not started','Studying','Revised once','Revised twice','Mastered'];
 const action=`<button class="btn" id="bookmarkBtn" aria-label="Bookmark topic">${bookmarks[t.id]?'★ Bookmarked':'☆ Bookmark'}</button><select id="statusSelect" aria-label="Revision status">${opts.map(o=>`<option ${selected===o?'selected':''}>${o}</option>`).join('')}</select>`;
 const article=s.type==='pdf'
 ? `<p class="muted">This specialty is retained in its original PDF layout to preserve all diagrams and formatting. Use the viewer or open it in a separate browser tab.</p><p><a class="btn" target="_blank" rel="noopener" href="${s.pdf}#page=${t.page}">Open original PDF · page ${t.page}</a></p><iframe class="pdf-view" title="${escapeHTML(t.title)}" src="${s.pdf}#page=${t.page}"></iframe>`
 : `<div class="reader" id="article" style="font-size:${settings.font}px">${t.html}</div>`;
 $('app').innerHTML=`<div style="margin-bottom:12px">${button('← '+escapeHTML(s.short),'/specialty/'+s.id)}</div><div class="reader-top"><div><h1 style="font-size:clamp(24px,3vw,31px);margin:5px 0">${escapeHTML(t.title)}</h1><div class="muted">${escapeHTML(s.name)} · Topic ${t._index+1} of ${others.length}</div></div><div class="actions">${action}</div></div><div class="panel toc" id="tocContainer" style="display:none"></div>${article}<div class="reader-nav">${previous?button('← Previous','/topic/'+encodeURIComponent(previous.id)):'<span></span>'}${next?button('Next →','/topic/'+encodeURIComponent(next.id)):'<span></span>'}</div><p class="foot">Personal study material, displayed as supplied. Clinical details have not been independently verified.</p>`;
 $('bookmarkBtn').onclick=()=>{bookmarks[t.id]=!bookmarks[t.id];persist('bookmarks',bookmarks);$('bookmarkBtn').textContent=bookmarks[t.id]?'★ Bookmarked':'☆ Bookmark'};
 $('statusSelect').onchange=e=>{progress[t.id]=e.target.value;persist('progress',progress)};
 if(s.type==='docx'){
  let headings=[...$('article').querySelectorAll('h3,h4,h5,h6')];
  if(headings.length>1){
    headings.forEach((h,i)=>h.id='section-'+i);
    $('tocContainer').style.display='block';
    $('tocContainer').innerHTML='<strong>On this page</strong><div style="max-height:260px;overflow:auto;margin-top:10px">'+headings.map((h,i)=>`<a href="#section-${i}" data-scroll="${i}" style="padding-left:${Math.min(26,(Number(h.tagName[1])-3)*10)}px">${escapeHTML(h.textContent)}</a>`).join('')+'</div>';
    $('tocContainer').querySelectorAll('[data-scroll]').forEach(a=>a.onclick=e=>{e.preventDefault();document.getElementById('section-'+a.dataset.scroll).scrollIntoView({behavior:'smooth',block:'start'})});
  }
 }
}
function searchPage(){
 let q=new URLSearchParams((fromHash().split('?')[1]||'')).get('q')||'';
 $('app').innerHTML=shell('Search your notes','Search topic titles and the text inside your DOCX study notes.',button('← Home','/'))+
 `<div class="searchbox"><input class="search" id="query" placeholder="Search: remifentanil, ATLS, nerve block…" value="${escapeHTML(q)}"></div><div class="topic-list" id="results"></div>`;
 const update=()=>{
  const v=$('query').value.trim().toLocaleLowerCase();
  const found=v.length<2?[]:allTopics().map(t=>({...t,_matches:(t.title+' '+(t.plain||'')).toLocaleLowerCase().split(v).length-1})).filter(t=>t._matches>0).sort((a,b)=>b._matches-a._matches).slice(0,100);
  $('results').innerHTML=v.length<2?'<div class="empty">Type at least two characters to search.</div>':found.length?`<div class="muted">${found.length}${found.length===100?'+':''} matching topics</div>`+found.map(topicCard).join(''):'<div class="empty">No matches found. The original PDF is searchable in its PDF viewer but not full-text indexed here.</div>';
 };
 $('query').oninput=update;update();
}
function bookmarkPage(){
 let result=allTopics().filter(t=>bookmarks[t.id]);
 $('app').innerHTML=shell('Bookmarked topics','Quick access to your saved study material.')+
 (result.length?`<div class="topic-list">${result.map(topicCard).join('')}</div>`:'<div class="empty">No bookmarks yet. Open a topic and press ☆ Bookmark.</div>');
}
function progressPage(){
 const statuses=['Not started','Studying','Revised once','Revised twice','Mastered'];
 const total=allTopics();
 $('app').innerHTML=shell('Revision progress','Your progress is saved privately in this browser.')+
 `<div class="stats">${statuses.slice(1,4).map(s=>`<div class="stat"><strong>${total.filter(t=>status(t)===s).length}</strong><span>${s}</span></div>`).join('')}</div>`+
 `<div class="panel"><h3>Progress by specialty</h3>${library.map(s=>`<div style="margin:20px 0"><div style="display:flex;justify-content:space-between"><strong>${escapeHTML(s.short)}</strong><span>${pct(s)}% started</span></div><div class="progressbar" style="margin-top:9px"><div style="width:${pct(s)}%"></div></div></div>`).join('')}</div><h3>Needs revision</h3><div class="topic-list">${total.filter(t=>['Studying','Revised once'].includes(status(t))).slice(0,30).map(topicCard).join('')||'<div class="empty">Mark a topic as Studying or Revised once to see it here.</div>'}</div>`;
}
function settingsPage(){
 $('app').innerHTML=shell('Settings','Make the reading experience comfortable.')+
 `<div class="panel"><div class="settings"><label for="fontSlider"><strong>Reading font size</strong></label><input id="fontSlider" type="range" min="14" max="24" value="${settings.font}"><span id="fontLabel">${settings.font}px</span></div><hr style="margin:24px 0;border:0;border-top:1px solid #e7edf5"><label><input type="checkbox" id="darkToggle" ${settings.dark?'checked':''}> Use dark mode</label></div><div class="panel"><h3>About saved progress</h3><p class="muted">Bookmarks and revision progress are stored in this browser on this device. Updating the GitHub files normally keeps them, provided you use the same site address and browser and do not clear site data.</p><p class="muted">No sign-in, upload, or in-app document-import feature is included. New study documents are integrated into new app releases.</p><button class="btn" id="exportProgress">Export progress backup (.json)</button> <label class="btn" for="importProgress">Restore progress backup</label><input id="importProgress" type="file" accept="application/json" hidden></div>`;
 $('fontSlider').oninput=e=>{$('fontLabel').textContent=e.target.value+'px';settings.font=+e.target.value;persist('settings',settings)};
 $('darkToggle').onchange=e=>{settings.dark=e.target.checked;persist('settings',settings);document.body.classList.toggle('dark',settings.dark)};
 $('exportProgress').onclick=()=>{const blob=new Blob([JSON.stringify({version:1,progress,bookmarks},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='dnb-study-progress.json';a.click();URL.revokeObjectURL(a.href)};
 $('importProgress').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const obj=JSON.parse(await f.text());if(!obj||obj.version!==1||typeof obj.progress!=='object'||typeof obj.bookmarks!=='object')throw Error();progress=obj.progress;bookmarks=obj.bookmarks;persist('progress',progress);persist('bookmarks',bookmarks);alert('Progress restored successfully.')}catch{alert('This file is not a valid DNB Study Hub progress backup.')}};
}
function errorPage(){$('app').innerHTML=shell('Page not found','Choose a specialty to continue.')+button('Return home','/')}
function render(){
 nav();let p=fromHash(),parts=p.split('/').filter(Boolean);
 if(!parts.length)return dashboard();
 if(parts[0]==='specialty')return specialty(parts[1]);
 if(parts[0]==='topic')return reader(parts.slice(1).join('/'));
 if(parts[0]==='search')return searchPage();
 if(parts[0]==='bookmarks')return bookmarkPage();
 if(parts[0]==='progress')return progressPage();
 if(parts[0]==='settings')return settingsPage();
 return errorPage();
}
document.addEventListener('click',e=>{
 const link=e.target.closest('[data-link]');
 if(link){navigate(link.dataset.link);return}
 const img=e.target.closest('.reader img.note-image');
 if(img){$('lightboxRoot').innerHTML=`<div class="lightbox" id="lightbox"><button id="closeLightbox" aria-label="Close image">×</button><img src="${img.getAttribute('src')}" alt="Expanded diagram"></div>`;$('closeLightbox').onclick=()=>{$('lightboxRoot').innerHTML=''};$('lightbox').onclick=event=>{if(event.target.id==='lightbox')$('lightboxRoot').innerHTML=''}}
});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('lightboxRoot').innerHTML='';$('sidebar').classList.remove('show')}if(e.key==='Enter'&&e.target.matches('[data-link]'))navigate(e.target.dataset.link)});
$('menuBtn').onclick=()=>$('sidebar').classList.toggle('show');
$('mobileHome').onclick=()=>navigate('/');
window.addEventListener('hashchange',render);
(async()=>{
 try{
  const index=await(await fetch('data/index.json')).json();
  const datasets=await Promise.all(index.map(async item=>await(await fetch(item.path)).json()));
  library=datasets;specs=index;history=saved('recent',[]);render();
 }catch(err){
  $('app').innerHTML='<div class="panel"><h2>Could not load study content</h2><p>Please open the app through GitHub Pages or a local web server, rather than opening index.html directly as a file.</p><p>'+escapeHTML(err.message)+'</p></div>';
 }
})();

if('serviceWorker' in navigator && (location.protocol==='https:' || location.hostname==='localhost')){
 window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
}
