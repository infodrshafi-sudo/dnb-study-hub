/* Search index loads only on first use, off the main UI thread. */
'use strict';
const indexCache=new Map();
let pending=null;
async function collect(specs){
 const docs=[];let failed=0;
 // Four concurrent specialty-index requests: avoids one massive initial load.
 let current=0;
 const tasks=Array.from({length:Math.min(4,specs.length)},async()=>{
   for(;;){const i=current++;if(i>=specs.length)break;const s=specs[i];
     try{if(!indexCache.has(s.id)){const r=await fetch(s.path);if(!r.ok)throw new Error(String(r.status));indexCache.set(s.id,await r.json())}docs.push(...indexCache.get(s.id));}
     catch(e){failed++;}
   }
 });
 await Promise.all(tasks);return {docs,partial:failed>0};
}
function excerpt(text,query){const s=String(text||''),i=s.toLocaleLowerCase().indexOf(query.toLocaleLowerCase());if(i<0)return s.slice(0,165);const st=Math.max(0,i-72),end=Math.min(s.length,i+query.length+125);return (st?'…':'')+s.slice(st,end)+(end<s.length?'…':'')}
function rank(d,q){const title=d.title.toLocaleLowerCase(),headings=(d.headings||[]),body=d.text.toLocaleLowerCase();const inTitle=title.includes(q),section=headings.findIndex(h=>h.toLocaleLowerCase().includes(q));const first=body.indexOf(q);if(!inTitle&&section===-1&&first<0)return null;
 const n=body.split(q).length-1;const score=(inTitle?1200:0)+(section>=0?550:0)+Math.min(200,n*5);return {id:d.id,title:d.title,score,section:section>=0?section:null,snippet:inTitle&&!body.includes(q)?d.title:excerpt(d.text,q)};}
self.onmessage=async e=>{const m=e.data;if(m.type!=='search')return;const requestId=m.requestId;const q=String(m.query||'').toLocaleLowerCase().trim();if(q.length<2){self.postMessage({requestId,results:[],count:0,partial:false});return}
 try{const {docs,partial}=await collect(m.specs);const matches=[];for(const d of docs){const r=rank(d,q);if(r)matches.push(r)}matches.sort((a,b)=>b.score-a.score||a.title.localeCompare(b.title));self.postMessage({requestId,results:matches.slice(0,90),count:matches.length,partial});}
 catch(error){self.postMessage({requestId,error:String(error.message||error)})}
};
