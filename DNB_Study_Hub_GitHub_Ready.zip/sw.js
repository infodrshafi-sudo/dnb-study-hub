/* Offline web shell plus network-first notes with cached fallback. */
const CORE_NAME='dnb-shell-v4.0.1';
const DYNAMIC_NAME='dnb-offline-library';
const CORE=['./','./index.html','./app.js','./search-worker.js','./style.css','./manifest.webmanifest','./assets/icon.svg','./assets/icon-192.png','./assets/icon-512.png','./data/index.json','./data/related.json','./data/aliases.json'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CORE_NAME).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('dnb-shell-')&&k!==CORE_NAME).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',event=>{
 const req=event.request;
 if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;
 event.respondWith((async()=>{
  try{const response=await fetch(req);
    if(response.ok&&!req.headers.has('range')){
      const c=await caches.open(DYNAMIC_NAME);c.put(req,response.clone()).catch(()=>{});
    }
    return response;
  }catch(e){const match=await caches.match(req);if(match)return match;
    if(req.mode==='navigate'){const cached=await caches.match('./index.html');if(cached)return cached;}
    throw e;
  }
 })());
});
